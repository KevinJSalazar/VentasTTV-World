/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.ventattv;

/**
 *
 * @author User A1
 */
public class Starter {
    public static void main(String[] args){
        App.main(args);
    }
}
